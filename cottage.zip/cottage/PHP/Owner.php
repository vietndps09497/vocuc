<?php

if(isset($_POST['txtName'])){
    $name = $_REQUEST['txtName'];
    $address = $_REQUEST['txtAddress'];
    $email = $_REQUEST['txtEmail'];
    $area = $_REQUEST['txtArea'];
    $landArea = $_REQUEST['txtLandArea'];
    $lenght = $_REQUEST['txtLenght'];
    $phone = $_REQUEST['txtPhone'];

    echo $name.'|'.$address.' | '.$email.' | '.$area;
}