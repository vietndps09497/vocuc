<?php 

if(isset($_POST['your-name'])){
    $name = $_REQUEST['your-name'];
    $phone = $_REQUEST['your-phone'];
    $build = $_REQUEST['build-type'];
    $email = $_REQUEST['your-email'];
    $message = $_REQUEST['your-message'];

    $to ='harry@monicacentral.co';
    $subject = 'test';
    $headers = 'from: '.$name." <".$email."> \r\n";
    $send_email = mail($to,$subject,$message,$headers);
    if($send_email){
        $response = ['status' => 'success'];
    }
    else
    {
      $response = ['status' => 'error'];
    }
    echo $response;
//    echo $name . " | " .$email." | ".$build." | ".$phone." | ".$message;  
}
